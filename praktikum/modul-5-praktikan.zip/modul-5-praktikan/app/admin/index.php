<?php 
$title = "Beranda Admin";
$page  = "beranda";
?>

<?php require_once("templates/header.php"); ?>

    
<?php require_once("templates/footer.php"); ?>