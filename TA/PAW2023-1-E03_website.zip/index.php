<?php 
header('Location: ./app/');
?>