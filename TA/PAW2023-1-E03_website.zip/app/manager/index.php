<?php 
header("Location:transaction-paid.php");
?>