	<footer>
		<div class="footer-container">
			Copyright © 2023 - PAW2023-1-E03
		</div>
	</footer>

	<script src="<?= BASEURL ?>/assets/js/script.js"></script>
	</body>

</html>